package com.example.exceptionhandling;

public class EntityNotFoundException extends Exception {
	public EntityNotFoundException (String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}

