package com.example.exceptionhandling;

public class RoomAlreadyBookedException extends RuntimeException {
	public RoomAlreadyBookedException (String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
