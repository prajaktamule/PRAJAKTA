package com.example.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.entity.Reservation;

public interface ReservationRepository extends JpaRepository <Reservation, Integer> {
	 @Query("SELECT r FROM Reservation r WHERE r.room.id = :roomId " +
	           "AND ((r.checkInDate BETWEEN :checkInDate AND :checkOutDate) OR " +
	           "     (r.checkOutDate BETWEEN :checkInDate AND :checkOutDate))")
	    List<Reservation> checkRoomAvailability( Integer roomId, String checkInDate, String checkOutDate);

}
